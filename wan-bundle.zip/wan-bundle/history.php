<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- import google font -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <link rel="stylesheet" href="css/common.css"/>
        <link rel="stylesheet" href="css/form.css"/>
        <title>Order History</title>
        <style type="text/css">
            .copyright-section.fixed{
                width: -webkit-fill-available;
                border-top: 3px solid #ecf3ff;
                bottom: 0;
                position: fixed;
                padding: 22px 85px 24px;
            }

            .z0{
                z-index: unset;
            }

            .itemrow{
                display: flex;
                align-items: center;
                padding-bottom: 15px;
                gap: 20px;
            }

            .itemrow .innerbox{
                padding-top: 40px;
            }

            .itemrow img{
                width: 120px;
                border-radius: 4px;
            }

            .inline{
                display: flex;
                align-items: left;
                flex-direction: column;
                gap: 10px;
            }

            .inline .title{
                font-weight: 600;
                font-size: 16px;
            }

            .inline p{
                font-size: 14px;
            }
        </style>

    </head>
    <body>  
        
        <?php include 'component/topbar.php'; ?>

        <section class="page-header">

            <div class="box">

                <div class="title-row">
                    <!-- <span class="round-shape"></span> -->
                    <h2 class="banner-title z0">Order History</h2>
                </div>
                <div class="bread-crumb z0">
                    <a href="index.php">Home</a> / Order History
                </div>
                
            </div>
            
        </section>

        <section class="checkout-section" style="padding-top: 0px;">
            <div class="container">
                <div class="checkout-box" style="width: 100%;">
                    <div style="overflow: auto; width: 100%;">
                        <div class="billing-fields">
                            <h3>Order</h3>

                            <?php 
                                 $sqlO = "SELECT * FROM new_order WHERE user_id = '$cid'";
                                 $resultO = mysqli_query($conn, $sqlO);


                            ?>
                            <div class="table_page table-responsive" style="min-width: 1000px;">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Order</th>
                                            <th>Date</th>
                                            <th>Delivery Address</th>
                                            <th>Status</th>
                                            <th>Total</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php

                                            if (mysqli_num_rows($resultO) > 0) {

                                                $count = 1;
                                                while($rowO = mysqli_fetch_assoc($resultO)) {

                                                    $oid = $rowO['order_id'];

                                                    $sqlSum = "SELECT SUM(price) AS sum, SUM(qty) AS sumQty  FROM order_item WHERE order_id = '$oid' ";
                                                    $resultSum = mysqli_query($conn, $sqlSum);
                                                    $rowSum = mysqli_fetch_assoc($resultSum);
                                                    

                                                    if($rowO['order_status'] == 'completed'){
                                                        $status = '<span class="text-success">Completed</span>';
                                                    }else if($rowO['order_status'] == 'delivering'){
                                                        $status = '<span class="text-warning">Delivering</span>';
                                                    }else if($rowO['order_status'] == 'cancelled'){
                                                        $status = '<span class="text-danger">Cancelled</span>';
                                                    }else{
                                                        $status = '<span>Pending</span>';
                                                    }

                                                    echo '<tr>
                                                            <td>'.$count.'</td>
                                                            <td>'.$rowO['order_created'].'</td>
                                                            <td>'.$rowO['delivery_address'].'</td>
                                                            <td>'.$status.'</td>
                                                            <td>RM'.number_format($rowSum['sum'], 2).' for '.$rowSum['sumQty'].' item</td>
                                                            <td>

                                                                <label class="btn view" for="modal-'.$oid.'">View</label>

                                                            </td>
                                                          </tr>';
                                                    $count++;

                                                    echo '
                                                        <input class="modal-state" id="modal-'.$oid.'" type="checkbox" />
                                                        <div class="modal">
                                                              <label class="modal__bg" for="modal-'.$oid.'"></label>
                                                              <div class="modal__inner">
                                                                <label class="modal__close" for="modal-'.$oid.'"></label>
                                                                <div class="innerbox">';

                                                                $sqlP = "SELECT id, product_id, qty, price  FROM order_item WHERE order_id = '$oid' ";
                                                                            $resultP = mysqli_query($conn, $sqlP);


                                                                            while($rowP = mysqli_fetch_assoc($resultP)) {

                                                            
                                                                                    $pid = $rowP['product_id'];
                                                                                    $itemid = $rowP['id'];
                                                                                    $itemid = $rowP['id'];

                                                                                    $sqlDetail = "SELECT *  FROM product WHERE product_id = '$pid' ";
                                                                                    $resultD = mysqli_query($conn, $sqlDetail);


                                                                                    $rowD = mysqli_fetch_assoc($resultD);

                                                                                   
                                                                                    echo '<div class="itemrow">

                                                                                            <img class="img-fluid" src="admin/upload/'.$rowD["product_image"].'">

                                                                                            <div class="inline">

                                                                                                <div class="title">'.$rowD["product_name"].'</div>
                                                                                                <p>Ordered Qty : &nbsp;'.$rowP['qty'].'</p>
                                                                                                <p>Total: RM'.number_format($rowP['price'],2).'</p>

                                                                          

                                                                                            </div>

                                                                                         </div>';

                                                                                  


                                                                            }

                                                        echo '    </div>
                                                              </div>
                                                        </div>';
                                                }
                                              
                                            } else {
                                                
                                                echo "<tr><td colspan='6'>No Order Yet</td></tr>";

                                            }



                                        ?>
                                        
                                      
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
            <input class="modal-state" id="modalR" type="checkbox" />
          
        </section>


        <?php include 'component/footer.php'; ?>
       
        
     

    </body>
</html>