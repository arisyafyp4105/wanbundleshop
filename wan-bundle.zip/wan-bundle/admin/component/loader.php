<div id="overlay">
	  <div class="cv-spinner">
	    <span class="spinner"></span>
	  </div>
</div>