<footer class="sticky-footer">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span class="text-dark">Copyright &copy; WAN BUNDLE SHOP</span>
        </div>
    </div>
</footer>