


<section class="copyright-section">
	<div class="copyrightbox">
		<div class="left">
           	<ul class="menu-link">
               <li><a href="admin/index.php">Admin Login</a></li> 
               <!-- <li><a href="#">Terms of Service</a></li> -->
            </ul>
        </div>
        <div class="right">
            <div class="copys-text"><i class="fa-regular fa-copyright"></i> Copyright WAN BUNDLE SHOP | All Rights Reserved</div>
        </div>
    </div>
</section>

<script src="js/jquery.js"></script>
<script src="js/common.js"></script>

<script type="text/javascript">
	$(document).ready(function(){

		$('#menuM').on('click', function(){

			if($('#m-menu').hasClass('active')){
				$('#m-menu').removeClass('active');
			}else{
				$('#m-menu').addClass('active');
			}
			

		});

		var cid = '<?php echo $cid; ?>';
		if(cid !== ""){
			checkCart();
		}

	});
        

</script>